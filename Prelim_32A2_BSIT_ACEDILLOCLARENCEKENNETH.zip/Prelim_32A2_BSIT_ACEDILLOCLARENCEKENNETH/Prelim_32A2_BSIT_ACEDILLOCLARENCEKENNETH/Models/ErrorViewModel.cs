namespace Prelim_32A2_BSIT_ACEDILLOCLARENCEKENNETH.Models
{
    public class ErrorViewModel
    {
        public string? RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}
